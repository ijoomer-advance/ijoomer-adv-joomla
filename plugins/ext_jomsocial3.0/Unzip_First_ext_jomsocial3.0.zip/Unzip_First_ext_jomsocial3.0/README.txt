Install ext_jomsocial3.0_v1.5.zip under iJoomerAdvance Component
Install plg_ijoomeradvVoice.zip under Joomla->Extension Manager
Install plg_ijoomeradvSmiley.zip under Joomla->Extension Manager
 

jQuery(document).ready(function()
{
	jQuery('#select').click(function(e)
	{
		jQuery('#myModal').modal('show');
	});
});


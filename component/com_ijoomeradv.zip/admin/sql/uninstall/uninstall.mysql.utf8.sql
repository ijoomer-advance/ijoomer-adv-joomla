DROP TABLE IF EXISTS `#__ijoomeradv_config`;
DROP TABLE IF EXISTS `#__ijoomeradv_extensions`;
DROP TABLE IF EXISTS `#__ijoomeradv_icms_config`;
DROP TABLE IF EXISTS `#__ijoomeradv_menu`;
DROP TABLE IF EXISTS `#__ijoomeradv_menu_types`;
DROP TABLE IF EXISTS `#__ijoomeradv_users`;
DROP TABLE IF EXISTS `#__ijoomeradv_notification`;